
void playGame( Game *game );

void showGame( Game *game );

int makeMove( Game *game, char symbol,int width, int depth );



