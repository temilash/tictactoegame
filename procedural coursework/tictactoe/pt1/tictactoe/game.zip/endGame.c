
#include <stdio.h>

#include "game.h"
#include "endGame.h"

/*
 * Functions in this module check for wins and draws
 */

// test all possible ways the game can be won for one player
int winGame( Game *game, char symbol ) {



  // return 1(true) if game is won, 0(false) otherwise
  //
  // You may wish to define further functions to test different win conditions
  // Games can be won with horizontal, vertical or diagonal lines


  //checking horizontal
  if(game->board[0][0] == symbol && game->board[0][1] == symbol && game->board[0][2] == symbol)
  {
      return 1;
  }


  if(game->board[1][0] == symbol && game->board[1][1] == symbol && game->board[1][2] == symbol)
  {
      return 1;
  }


  if(game->board[2][0] == symbol && game->board[2][1] == symbol && game->board[2][2] == symbol)
  {
      return 1;
  }

  //check vertical
  if(game->board[0][0] == symbol && game->board[1][0] == symbol && game->board[2][0] == symbol)
  {
      return 1;
  }


  if(game->board[0][1]== symbol && game->board[1][1]== symbol && game->board[2][1] == symbol)
  {
      return 1;
  }


  if(game->board[0][2] == symbol && game->board[1][2] == symbol && game->board[2][2] == symbol)
  {
      return 1;
  }


  if(game->board[0][0] == symbol && game->board[1][1] == symbol && game->board[2][2] == symbol)
  {
      return 1;
  }

  //check diagonal
  if(game->board[0][0] == symbol && game->board[1][1] == symbol && game->board[2][2] == symbol)
  {
      return 1;
  }


  if(game->board[2][0] == symbol && game->board[1][1] == symbol && game->board[0][2] == symbol)
  {
      return 1;
  }




  return 0;  // continue
}

// test for a draw
int drawGame( Game *game ) {

  if(game->turns == 9){
    if(winGame(game,'X') == 0)
    {
        printf("Game is a draw");
    }
  }

  return 0; // continue
}

