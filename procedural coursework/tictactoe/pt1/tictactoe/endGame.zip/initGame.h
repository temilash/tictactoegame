
Game *initGame( );
