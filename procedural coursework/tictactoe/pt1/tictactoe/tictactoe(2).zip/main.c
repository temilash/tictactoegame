
#include <stdio.h>
#include <stdlib.h>

#include "game.h"
#include "initGame.h"
#include "playGame.h"
#include <string.h>

/*
 * main function: program entry point
 */

int main( int argc, char *argv[] ) {


  Game *game ; // pointer for the game structure

  Game *help = initGame();

  strcpy(game->board,help->board);
  game->boardSize = help->boardSize;
  game->turns = help->turns;
  game->winLength = help->winLength;
  game->maxTurns = help->maxTurns;



  playGame(game);

  // play a full game

  free( game ); // free heap memory that was used

  return 0;
}

